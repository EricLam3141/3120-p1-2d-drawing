# uncc_webgl_utils

This is a small set of JavaScript functions that supplement the libraries
included with either the WebGL Programming Guide (Matsuda & Lea) or Interactive
Computer Graphics 7th Edition (Angel & Shreiner).  They are used in ITCS 4120
at UNCC. 

git forks of the source code for these books are found here:

* [https://cci-git.uncc.edu/UNCC_Graphics_Third_Party_Libraries/ICG_Angel_7th.git]

* [https://cci-git.uncc.edu/UNCC_Graphics_Third_Party_Libraries/WebGL_Programming_Guide.git]
