add line

Things about this project :
    - Draws shapes, but not filled in with color. sides do have color though.
    - CAN delete shapes, but is done with middle mouse button after clicking delete button. 
    - Color can be adjusted, but not after shape is drawn.
    - You can select things, but does not outline entire shape, just 1 side of the shape (Can delete entire shape at once)
